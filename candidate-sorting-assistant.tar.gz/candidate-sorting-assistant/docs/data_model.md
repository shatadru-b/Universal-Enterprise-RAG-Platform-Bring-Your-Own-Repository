# Data Model (Initial)

Entities: Candidate, Job, CandidateMatch, Question, MockInterviewSession, MockInterviewAnswer.
Fields will expand with audit logging, notification, dashboard caching.
