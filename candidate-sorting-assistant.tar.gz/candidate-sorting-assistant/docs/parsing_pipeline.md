# Parsing Pipeline

1. Extract text (future: pdfminer / tika).
2. Normalize text.
3. Section segmentation (experience, education, projects) - stub.
4. Skill extraction via taxonomy.
5. Project extraction heuristics.
6. Determine latest significant project.
