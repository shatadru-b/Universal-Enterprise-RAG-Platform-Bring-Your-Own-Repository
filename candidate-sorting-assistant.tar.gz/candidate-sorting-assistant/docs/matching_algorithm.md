# Matching Algorithm

Weighted composite: 0.4 skill_overlap + 0.35 vector_similarity + 0.15 recent_project_relevance + 0.10 experience_alignment.
