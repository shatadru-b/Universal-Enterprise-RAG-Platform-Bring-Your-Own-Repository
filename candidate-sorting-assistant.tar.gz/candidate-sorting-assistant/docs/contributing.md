# Contributing

1. Fork & branch naming: feature/<short-desc>.
2. Run backend tests: `make test`.
3. Add/Update docs for feature changes.
4. Ensure type hints & lint pass (future: ruff, eslint).
