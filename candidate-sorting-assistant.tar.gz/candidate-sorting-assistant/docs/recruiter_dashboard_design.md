# Recruiter Dashboard Design

KPIs, score distribution (histogram), profile matching gauge, recent high matches table.
