# API Surface (Initial Subset)

Implemented: /api/v1/candidates (POST, GET by id), /api/v1/match_candidate, /api/v1/generate_questions, /api/v1/questions/{candidate_id}, /health/*, /api/v1/analytics/recruiter

Planned (per spec): parse_resume, bulk parse, job matching, mock interview flow, notifications, export, analytics aspirant.
