# Frontend Architecture

Vite + React + TypeScript. Zustand stores per domain (auth, candidates, metrics). Tailwind for utility-first styling.
