# Architecture Overview

High-level: FastAPI backend + dual React frontends (recruiter & candidate) + pluggable embedding/vector layer.

(Placeholder diagram description)
