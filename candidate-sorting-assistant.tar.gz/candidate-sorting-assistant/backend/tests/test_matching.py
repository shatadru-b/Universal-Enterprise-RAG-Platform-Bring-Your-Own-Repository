from app.services.matching.engine import MatchComputation
from app.models.entities import Candidate, Job

def test_match_basic():
    cand = Candidate(id=1, name="A", email="a@example.com", years_experience=5, skills=["python", "aws"], embedding=[0.1]*64)
    job = Job(id=1, title="Engineer", description="Need python and aws", required_skills=["python", "aws"], embedding=[0.1]*64)
    mc = MatchComputation(cand, job).compute()
    assert mc["components"]["skill_overlap"]["value"] == 1.0
    assert 0 <= mc["score_overall"] <= 1.0
