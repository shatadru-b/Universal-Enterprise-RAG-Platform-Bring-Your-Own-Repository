from app.services.resume_parser.parser import parse_resume

def test_parse_resume_extracts_skills_and_projects():
    text = """John Doe\nExperience: Did a Machine Learning project using Python and AWS.\nProject Alpha: Scalable API with Docker and Kubernetes."""
    result = parse_resume(text)
    assert "python" in result["skills"]
    assert result["latest_project_summary"] is not None
