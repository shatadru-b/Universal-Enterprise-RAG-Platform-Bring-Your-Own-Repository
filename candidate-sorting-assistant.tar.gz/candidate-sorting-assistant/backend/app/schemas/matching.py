from __future__ import annotations
from pydantic import BaseModel
from typing import List, Dict, Any

class MatchBreakdown(BaseModel):
    score_overall: float
    components: Dict[str, Any]
    matched_skills: List[str]
    missing_skills: List[str]
    partial_matches: List[str] | None = None
    latest_project_alignment: Dict[str, Any] | None = None

class MatchRequest(BaseModel):
    candidate_id: int
    job_description: str | None = None
    job_id: int | None = None

class MatchResponse(MatchBreakdown):
    candidate_id: int
    job_id: int | None = None
