from __future__ import annotations
from pydantic import BaseModel
from typing import List, Optional

class CandidateBase(BaseModel):
    name: str
    email: str
    years_experience: int = 0

class CandidateCreate(CandidateBase):
    resume_text: str | None = None

class CandidateRead(CandidateBase):
    id: int
    overall_match_score: float | None = None
    skills: List[str] | None = None
    latest_project_summary: str | None = None

    class Config:
        from_attributes = True
