from __future__ import annotations
from pydantic import BaseModel
from typing import List

class JobBase(BaseModel):
    title: str
    description: str
    required_years: int | None = None
    required_skills: List[str] | None = None
    critical_skills: List[str] | None = None

class JobCreate(JobBase):
    pass

class JobRead(JobBase):
    id: int

    class Config:
        from_attributes = True
