"""Security & RBAC primitives.

Provides dependency helpers for JWT validation (mock for now) and role enforcement.
"""
from __future__ import annotations
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from typing import List
from .config import settings

security_scheme = HTTPBearer(auto_error=False)

class UserContext:
    def __init__(self, sub: str, roles: list[str]):
        self.sub = sub
        self.roles = roles

    def has_role(self, *required: str) -> bool:
        return any(r in self.roles for r in required)

# Mock token decode for now
_DEF_MOCK_USER = UserContext(sub="user123", roles=["ADMIN", "RECRUITER", "ASPIRANT"])

def get_current_user(token: HTTPAuthorizationCredentials = Depends(security_scheme)) -> UserContext:
    if settings.auth_provider == "mock":
        return _DEF_MOCK_USER
    # Placeholder for real JWT processing
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    # TODO: decode & validate JWT, map roles
    return _DEF_MOCK_USER

def require_roles(*roles: str):
    def wrapper(user: UserContext = Depends(get_current_user)) -> UserContext:
        if not user.has_role(*roles):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
        return user
    return wrapper
