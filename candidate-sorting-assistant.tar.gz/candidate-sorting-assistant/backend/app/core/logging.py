"""Structured logging setup.

Uses standard library logging with JSON-like formatting (simple key=value for now).
Extensible to integrate with OpenTelemetry / external aggregators.
"""
from __future__ import annotations
import logging
import sys
from .config import settings

LOG_FORMAT = "%(asctime)s level=%(levelname)s msg=%(message)s module=%(module)s trace=%(name)s"

def configure_logging() -> None:
    root = logging.getLogger()
    if root.handlers:
        # Already configured
        return
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(LOG_FORMAT)
    handler.setFormatter(formatter)
    root.addHandler(handler)
    root.setLevel(settings.log_level.upper())

configure_logging()
logger = logging.getLogger("app")
