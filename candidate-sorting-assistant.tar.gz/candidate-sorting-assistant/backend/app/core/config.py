"""Application configuration module using 12-factor style via environment variables.

This module centralizes settings so other parts of the code only import a Config instance.
All defaults are safe for local development; production should override via environment.
"""
from __future__ import annotations
from pydantic import BaseModel, Field
import os
from functools import lru_cache

class Settings(BaseModel):
    app_name: str = "Candidate Sorting Assistant"
    environment: str = Field(default=os.getenv("ENVIRONMENT", "dev"))
    log_level: str = Field(default=os.getenv("LOG_LEVEL", "INFO"))
    # Database
    postgres_dsn: str = Field(default=os.getenv("POSTGRES_DSN", "postgresql+psycopg://postgres:postgres@localhost:5432/candidate_sorting"))
    # Auth / OIDC
    auth_provider: str = Field(default=os.getenv("AUTH_PROVIDER", "mock"))
    jwt_audience: str | None = os.getenv("JWT_AUDIENCE")
    jwt_issuer: str | None = os.getenv("JWT_ISSUER")
    # OpenAI / LLM
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    # Vector DB
    vector_db_provider: str = Field(default=os.getenv("VECTOR_DB_PROVIDER", "memory"))
    pinecone_api_key: str | None = os.getenv("PINECONE_API_KEY")
    qdrant_url: str | None = os.getenv("QDRANT_URL")
    # Storage
    s3_endpoint: str | None = os.getenv("S3_ENDPOINT")
    s3_bucket: str | None = os.getenv("S3_BUCKET")
    # Frontend origins
    frontend_url_recruiter: str = Field(default=os.getenv("FRONTEND_URL_RECRUITER", "http://localhost:5173"))
    frontend_url_candidate: str = Field(default=os.getenv("FRONTEND_URL_CANDIDATE", "http://localhost:5174"))
    # Limits
    max_resume_file_mb: int = int(os.getenv("MAX_RESUME_FILE_MB", "10"))

    class Config:
        extra = "ignore"

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
