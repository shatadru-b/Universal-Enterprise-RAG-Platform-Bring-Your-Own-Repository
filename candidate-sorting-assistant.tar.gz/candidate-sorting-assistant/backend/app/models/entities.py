from __future__ import annotations
"""Core ORM entities for initial scaffold.

Embedding fields stored as simple JSON (list[float]) for portability; can be migrated to vector types.
"""
from sqlalchemy import String, Integer, ForeignKey, DateTime, Float, JSON, Text, Enum, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime
from app.db.base import Base
import enum

class RoleEnum(str, enum.Enum):
    ADMIN = "ADMIN"
    RECRUITER = "RECRUITER"
    ASPIRANT = "ASPIRANT"

class Candidate(Base):
    __tablename__ = "candidates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(255), index=True)
    years_experience: Mapped[int] = mapped_column(Integer, default=0)
    resume_text: Mapped[str | None] = mapped_column(Text())
    overall_match_score: Mapped[float | None] = mapped_column(Float())
    last_matched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    skills: Mapped[list[str] | None] = mapped_column(JSON)
    latest_project_summary: Mapped[str | None] = mapped_column(Text())
    embedding: Mapped[list[float] | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text())
    required_years: Mapped[int | None] = mapped_column(Integer)
    required_skills: Mapped[list[str] | None] = mapped_column(JSON)
    critical_skills: Mapped[list[str] | None] = mapped_column(JSON)
    embedding: Mapped[list[float] | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class CandidateMatch(Base):
    __tablename__ = "candidate_matches"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    score_overall: Mapped[float] = mapped_column(Float())
    components: Mapped[dict] = mapped_column(JSON)
    matched_skills: Mapped[list[str] | None] = mapped_column(JSON)
    missing_skills: Mapped[list[str] | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class Question(Base):
    __tablename__ = "questions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id", ondelete="CASCADE"), index=True)
    text: Mapped[str] = mapped_column(Text())
    category: Mapped[str] = mapped_column(String(50))
    difficulty: Mapped[str] = mapped_column(String(20))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class MockInterviewSession(Base):
    __tablename__ = "mock_interview_sessions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id", ondelete="CASCADE"), index=True)
    question_snapshot: Mapped[list[dict] | None] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(30), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

class MockInterviewAnswer(Base):
    __tablename__ = "mock_interview_answers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("mock_interview_sessions.id", ondelete="CASCADE"), index=True)
    question_id: Mapped[int] = mapped_column(ForeignKey("questions.id", ondelete="SET NULL"), nullable=True)
    answer_text: Mapped[str | None] = mapped_column(Text())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
