"""Base declarative class and import side-effects for models."""
from __future__ import annotations
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

# Import model modules here in future to ensure metadata population for Alembic
