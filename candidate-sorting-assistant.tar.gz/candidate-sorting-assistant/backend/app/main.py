from __future__ import annotations
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core import logging as _logging  # noqa: F401
from app.routers import candidates, matching, questions, analytics, health

app = FastAPI(title=settings.app_name)

origins = [settings.frontend_url_recruiter, settings.frontend_url_candidate]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(candidates.router)
app.include_router(matching.router)
app.include_router(questions.router)
app.include_router(analytics.router)

@app.get("/")
async def root():
    return {"service": settings.app_name, "status": "ok"}
