from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Candidate
from app.schemas.candidate import CandidateCreate, CandidateRead
from app.core.security import require_roles
from app.services.resume_parser.parser import parse_resume
from app.services.embeddings.provider import get_embedding_provider

router = APIRouter(prefix="/api/v1", tags=["candidates"])

@router.post("/candidates", response_model=CandidateRead, dependencies=[Depends(require_roles("RECRUITER", "ADMIN"))])
def create_candidate(payload: CandidateCreate, db: Session = Depends(get_db)):
    data = Candidate(**payload.dict())
    # Basic parsing if resume text provided
    if payload.resume_text:
        parsed = parse_resume(payload.resume_text)
        data.skills = parsed.get("skills")
        data.latest_project_summary = parsed.get("latest_project_summary")
        emb = get_embedding_provider().embed(payload.resume_text)
        data.embedding = emb
    db.add(data)
    db.commit()
    db.refresh(data)
    return data

@router.get("/candidates/{candidate_id}", response_model=CandidateRead)
def get_candidate(candidate_id: int, db: Session = Depends(get_db)):
    c = db.get(Candidate, candidate_id)
    if not c:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return c
