from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Candidate, Job, CandidateMatch
from app.schemas.matching import MatchRequest, MatchResponse
from app.services.matching.engine import MatchComputation
from app.core.security import require_roles
from datetime import datetime

router = APIRouter(prefix="/api/v1", tags=["matching"])

@router.post("/match_candidate", response_model=MatchResponse, dependencies=[Depends(require_roles("RECRUITER", "ADMIN"))])
def match_candidate(payload: MatchRequest, db: Session = Depends(get_db)):
    cand = db.get(Candidate, payload.candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    if payload.job_id:
        job = db.get(Job, payload.job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
    else:
        # Create ephemeral job from description
        if not payload.job_description:
            raise HTTPException(status_code=400, detail="job_description or job_id required")
        job = Job(title="Ephemeral", description=payload.job_description)
    comp = MatchComputation(cand, job).compute()
    cand.overall_match_score = comp["score_overall"]
    cand.last_matched_at = datetime.utcnow()
    match_row = CandidateMatch(candidate_id=cand.id, job_id=job.id if job.id else None, **comp)
    db.add(match_row)
    db.commit()
    db.refresh(cand)
    return MatchResponse(candidate_id=cand.id, job_id=job.id if job.id else None, **comp)
