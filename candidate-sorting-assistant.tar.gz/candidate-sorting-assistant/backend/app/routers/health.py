from fastapi import APIRouter

router = APIRouter(tags=["health"])  # Simple liveness/readiness endpoints

@router.get("/health/live")
async def liveness():
    return {"status": "live"}

@router.get("/health/ready")
async def readiness():
    # TODO: add deeper checks (DB, vector store, external services)
    return {"status": "ready"}
