from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Candidate, Question
from app.services.question_generator.generator import generate_questions
from app.core.security import require_roles

router = APIRouter(prefix="/api/v1", tags=["questions"])

@router.post("/generate_questions")
async def generate_candidate_questions(candidate_id: int, db: Session = Depends(get_db)):
    cand = db.get(Candidate, candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    qs = generate_questions(cand.skills or [], cand.years_experience, cand.latest_project_summary, n=12)
    created = []
    for q in qs:
        row = Question(candidate_id=cand.id, text=q["text"], category=q["category"], difficulty=q["difficulty"])
        db.add(row)
        created.append(row)
    db.commit()
    return {"count": len(created)}

@router.get("/questions/{candidate_id}")
def list_questions(candidate_id: int, db: Session = Depends(get_db)):
    return db.query(Question).filter(Question.candidate_id == candidate_id).order_by(Question.created_at.desc()).limit(100).all()
