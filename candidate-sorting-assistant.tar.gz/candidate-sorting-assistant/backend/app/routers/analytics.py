from __future__ import annotations
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Candidate, CandidateMatch

router = APIRouter(prefix="/api/v1", tags=["analytics"])

@router.get("/analytics/recruiter")
async def recruiter_dashboard(db: Session = Depends(get_db)):
    total_candidates = db.query(Candidate).count()
    avg_score = db.query(Candidate).filter(Candidate.overall_match_score.is_not(None)).count()
    return {
        "total_candidates": total_candidates,
        "average_match_score_placeholder": avg_score,
    }
