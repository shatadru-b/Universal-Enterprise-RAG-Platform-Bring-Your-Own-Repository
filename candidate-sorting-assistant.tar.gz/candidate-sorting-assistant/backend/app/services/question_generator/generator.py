"""Deterministic question generator fallback.

Future: integrate LLM provider abstraction.
"""
from __future__ import annotations
from typing import List, Dict

CATEGORIES = ["project_deep_dive", "technical_stack", "behavioral", "system_design"]

def generate_questions(skills: List[str], years: int, latest_project: str | None, n: int = 12) -> List[Dict]:
    out: List[Dict] = []
    difficulty = "easy"
    if years >= 7:
        difficulty = "hard"
    elif years >= 3:
        difficulty = "medium"
    include_system = years > 4
    idx = 0
    for cat in CATEGORIES:
        if cat == "system_design" and not include_system:
            continue
        out.append({
            "text": f"Describe a challenge related to {cat.replace('_', ' ')} from your recent project.",
            "category": cat,
            "difficulty": difficulty,
        })
        idx += 1
        if idx >= n:
            break
    # Fill remaining with skill-based prompts
    for s in skills[: max(0, n - len(out))]:
        out.append({
            "text": f"Explain how you have applied {s} in a practical setting.",
            "category": "technical_stack",
            "difficulty": difficulty,
        })
        if len(out) >= n:
            break
    return out
