"""Resume parsing pipeline stub.

Implements minimal extraction for early integration; extend with pdfminer / spaCy in future.
"""
from __future__ import annotations
from typing import List, Dict
import re

SKILL_TAXONOMY = ["python", "java", "javascript", "aws", "docker", "kubernetes", "sql", "react", "node"]

SECTION_PATTERNS = [
    ("experience", re.compile(r"experience", re.I)),
    ("education", re.compile(r"education", re.I)),
    ("projects", re.compile(r"projects?", re.I)),
]

def parse_resume(text: str) -> Dict:
    lower = text.lower()
    skills = sorted({s for s in SKILL_TAXONOMY if s in lower})
    # naive project extraction: lines containing 'project'
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    projects = [l for l in lines if 'project' in l.lower()][:5]
    latest_project = projects[0] if projects else None
    return {
        "skills": skills,
        "latest_project_summary": latest_project,
        "projects": projects,
    }
