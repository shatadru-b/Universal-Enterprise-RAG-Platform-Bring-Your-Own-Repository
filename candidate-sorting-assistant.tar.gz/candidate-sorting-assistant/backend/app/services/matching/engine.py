"""Matching engine implementing weighted scoring algorithm."""
from __future__ import annotations
from typing import List, Dict, Any
from app.models.entities import Candidate, Job
from app.services.embeddings.provider import cosine, get_embedding_provider

WEIGHTS = {
    "skill_overlap": 0.4,
    "vector_similarity": 0.35,
    "recent_project_relevance": 0.15,
    "experience_alignment": 0.10,
}

class MatchComputation:
    def __init__(self, candidate: Candidate, job: Job):
        self.candidate = candidate
        self.job = job
        self.emb = get_embedding_provider()

    def compute(self) -> Dict[str, Any]:
        required = set((self.job.required_skills or []) + [])
        cand_skills = set(self.candidate.skills or [])
        matched = sorted(required & cand_skills)
        missing = sorted(required - cand_skills)
        # partial matches placeholder (e.g., skill synonyms) - empty for now
        partial: List[str] = []
        skill_overlap = (len(matched) / len(required)) if required else 0.0
        vec_sim = cosine(self.candidate.embedding or [], self.job.embedding or [])
        # recent project relevance: naive similarity against job description for now
        recent_proj_text = self.candidate.latest_project_summary or ""
        rp_vec = cosine(self.emb.embed(recent_proj_text), self.job.embedding or []) if recent_proj_text else 0.0
        if not self.job.embedding and recent_proj_text:
            rp_vec = 0.5  # neutral fallback
        exp_align = 0.7
        if self.job.required_years and self.job.required_years > 0:
            exp_align = min(1.0, (self.candidate.years_experience or 0) / self.job.required_years)
        components = {
            "skill_overlap": {"value": skill_overlap, "weight": WEIGHTS["skill_overlap"]},
            "vector_similarity": {"value": vec_sim, "weight": WEIGHTS["vector_similarity"]},
            "recent_project_relevance": {"value": rp_vec, "weight": WEIGHTS["recent_project_relevance"]},
            "experience_alignment": {"value": exp_align, "weight": WEIGHTS["experience_alignment"]},
        }
        score = sum(v["value"] * v["weight"] for v in components.values())
        return {
            "score_overall": score,
            "components": components,
            "matched_skills": matched,
            "missing_skills": missing,
            "partial_matches": partial,
            "latest_project_alignment": {"recent_project_relevance": rp_vec},
        }
