"""Embedding provider abstraction with pluggable backends.

Current implementations:
- MemoryEmbeddingProvider: simple deterministic hash-based vector for offline/dev
Future: OpenAIEmbeddingProvider, Pinecone, Qdrant integration.
"""
from __future__ import annotations
from typing import List
import hashlib
import math

class EmbeddingProvider:
    def embed(self, text: str) -> List[float]:  # pragma: no cover - interface
        raise NotImplementedError

class MemoryEmbeddingProvider(EmbeddingProvider):
    dim: int = 64
    def embed(self, text: str) -> List[float]:
        h = hashlib.sha256(text.encode("utf-8")).digest()
        # repeat to fill dim
        raw = (h * ((self.dim // len(h)) + 1))[: self.dim]
        vec = [b / 255.0 for b in raw]
        # L2 normalize
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]

_provider_singleton: EmbeddingProvider | None = None

def get_embedding_provider() -> EmbeddingProvider:
    global _provider_singleton
    if _provider_singleton is None:
        _provider_singleton = MemoryEmbeddingProvider()
    return _provider_singleton

def cosine(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    return sum(x*y for x, y in zip(a, b)) / ((sum(x*x for x in a)**0.5) * (sum(y*y for y in b)**0.5) or 1.0)
