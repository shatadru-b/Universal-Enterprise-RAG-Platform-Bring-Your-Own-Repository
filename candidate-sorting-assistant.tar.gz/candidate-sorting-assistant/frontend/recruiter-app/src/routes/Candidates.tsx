export default function Candidates() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Candidates</h1>
      <p>List placeholder.</p>
    </div>
  );
}
