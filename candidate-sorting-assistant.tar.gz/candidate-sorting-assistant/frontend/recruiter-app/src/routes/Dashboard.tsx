export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Recruiter Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="p-4 rounded bg-white shadow">Total Candidates: <span className="font-bold">--</span></div>
        <div className="p-4 rounded bg-white shadow">Avg Match Score: <span className="font-bold">--</span></div>
        <div className="p-4 rounded bg-white shadow">Shortlisted: <span className="font-bold">--</span></div>
      </div>
    </div>
  );
}
