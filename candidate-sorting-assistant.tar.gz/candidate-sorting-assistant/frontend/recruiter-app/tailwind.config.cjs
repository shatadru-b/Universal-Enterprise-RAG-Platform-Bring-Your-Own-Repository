module.exports = {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        score: {
          excellent: '#16a34a',
          good: '#65a30d',
          moderate: '#d97706',
          low: '#dc2626'
        }
      }
    }
  },
  plugins: []
};
