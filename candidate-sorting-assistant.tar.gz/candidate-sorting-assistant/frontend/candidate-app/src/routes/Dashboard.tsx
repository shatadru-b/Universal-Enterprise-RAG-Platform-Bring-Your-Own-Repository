export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Candidate Dashboard</h1>
      <p>Readiness Index: --</p>
    </div>
  );
}
