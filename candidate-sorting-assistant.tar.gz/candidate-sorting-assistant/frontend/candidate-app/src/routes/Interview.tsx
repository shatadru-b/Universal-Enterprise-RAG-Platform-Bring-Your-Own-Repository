export default function Interview() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Mock Interview</h1>
      <p>Session placeholder.</p>
    </div>
  );
}
