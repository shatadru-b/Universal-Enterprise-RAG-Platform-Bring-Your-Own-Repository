import { Routes, Route, Link } from 'react-router-dom';
import Dashboard from './routes/Dashboard';
import Interview from './routes/Interview';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <nav className="p-4 flex gap-4 bg-white shadow">
        <Link to="/">Dashboard</Link>
        <Link to="/interview">Mock Interview</Link>
      </nav>
      <main className="p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/interview" element={<Interview />} />
        </Routes>
      </main>
    </div>
  );
}
