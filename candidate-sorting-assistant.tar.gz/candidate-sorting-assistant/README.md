# Candidate Sorting Assistant

Monorepo for a production-grade, cloud-ready SaaS enabling recruiters to parse resumes, compute candidate-job match scores, generate tailored interview questions, and support candidate mock interview sessions.

## Packages / Structure
- backend: FastAPI + SQLAlchemy + Pydantic v2
- frontend/recruiter-app: React 18 + TypeScript + Vite + Tailwind + Zustand + Recharts
- frontend/candidate-app: React 18 + TypeScript + Vite + Tailwind + Zustand
- shared: (placeholder for shared types/components)
- infrastructure: Docker & Kubernetes manifests
- docs: Architecture and design docs

## Tech Decisions
- State mgmt: Zustand (lightweight, simple store pattern) over Redux Toolkit for lower boilerplate.
- Charting: Recharts for composability + TypeScript types.
- Embeddings: pluggable provider abstraction with memory deterministic fallback. Future: OpenAI, Pinecone, Qdrant.
- Package mgmt (backend): requirements.txt + pip (could move to uv later).
- Auth: Mock OIDC provider stub (JWT hooks ready) until integration with Auth0/Azure AD.

## Quick Start (Backend)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn app.main:app --reload --app-dir backend/app
```

## Frontend Dev
```bash
cd frontend/recruiter-app && npm install && npm run dev
cd ../candidate-app && npm install && npm run dev
```

## Environment Variables
See `.env.example` for full list.

## Makefile Targets (planned)
- make dev
- make backend-dev
- make test
- make migrate
- make build
- make lint
- make format

## Next Steps
1. Flesh out remaining routers (jobs, mock interview session flow, export, notifications).
2. Implement real analytics aggregations.
3. Add OpenAI / vector DB provider toggles via env.
4. Build recruiter dashboard components (gauge, charts) + candidate interview runner.
5. Add RBAC decorators to all protected endpoints.
6. Integrate Alembic initial migration.
7. Add CI workflow & linting config (Ruff, ESLint). 
8. Expand tests (API + components).

## License
Proprietary (adjust as needed).
